import CategoryForm from "/.CategoryForm";

export default CategoryForm;
